import os
import shutil
from datetime import datetime

def create_backup():
    # Create backup directory if it doesn't exist
    backup_dir = "backups"
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)

    # Generate backup filename with timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_name = f"holmes_backup_{timestamp}"
    backup_path = os.path.join(backup_dir, backup_name)

    # Files and directories to exclude
    exclude = [
        'venv',
        '__pycache__',
        '*.pyc',
        'db.sqlite3',
        'media',
        'backups',
        '.git',
        '.env',
        '*.log'
    ]

    # Create a temporary directory for the backup
    temp_dir = "temp_backup"
    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)
    os.makedirs(temp_dir)

    # Copy project files
    for root, dirs, files in os.walk('.'):
        # Skip excluded directories
        dirs[:] = [d for d in dirs if not any(ex in d for ex in exclude)]
        
        for file in files:
            # Skip excluded files
            if any(ex in file for ex in exclude):
                continue
                
            # Get source and destination paths
            src_path = os.path.join(root, file)
            rel_path = os.path.relpath(src_path, '.')
            dst_path = os.path.join(temp_dir, rel_path)
            
            # Create destination directory if it doesn't exist
            os.makedirs(os.path.dirname(dst_path), exist_ok=True)
            
            # Copy file
            shutil.copy2(src_path, dst_path)

    # Create zip file
    shutil.make_archive(backup_path, 'zip', temp_dir)

    # Clean up temporary directory
    shutil.rmtree(temp_dir)

    print(f"Backup created successfully: {backup_path}.zip")

if __name__ == "__main__":
    create_backup() 